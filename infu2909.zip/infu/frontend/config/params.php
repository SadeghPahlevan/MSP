<?php
return [
    'adminEmail' => 'admin@example.com',
    'currentTheme' => 'default'
];
