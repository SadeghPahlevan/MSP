$(document).ready(function(){
    $(".logout-btn").click(function(){
        $("#logout-form").submit();
    });
});
