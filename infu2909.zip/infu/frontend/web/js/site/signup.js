/* codepen for signup*/
$(document).ready(function () {

});